from flask import Flask, request, render_template_string, jsonify
import pandas as pd
import sqlite3
from datetime import datetime

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

app = Flask(__name__)

# =========================================================
# CONFIGURATION
# =========================================================

DATASET = "placement_data.csv"
DATABASE = "placement.db"

# Change these names if your CSV uses different column names
FEATURES = [
    "CGPA",
    "AptitudeScore",
    "TechnicalSkills",
    "CommunicationSkills",
    "Internships",
    "Certifications",
    "Projects"
]

TARGET = "PlacementStatus"

# =========================================================
# LOAD DATASET
# =========================================================

df = pd.read_csv(DATASET)

print("\nDataset loaded successfully!")
print(df.head())
print("\nColumns:")
print(df.columns.tolist())


# =========================================================
# PREPROCESS DATA
# =========================================================

# Check required columns
missing_columns = [col for col in FEATURES + [TARGET] if col not in df.columns]

if missing_columns:
    raise ValueError(
        f"\nMissing columns in CSV: {missing_columns}\n"
        f"Available columns: {df.columns.tolist()}"
    )

# Remove duplicate rows
df = df.drop_duplicates()

# Fill missing numerical values
for col in FEATURES:
    df[col] = pd.to_numeric(df[col], errors="coerce")
    df[col] = df[col].fillna(df[col].median())

# Remove rows with missing target
df = df.dropna(subset=[TARGET])

# =========================================================
# ENCODE TARGET
# =========================================================

label_encoder = LabelEncoder()

df["TargetEncoded"] = label_encoder.fit_transform(
    df[TARGET].astype(str)
)

print("\nTarget classes:")
print(label_encoder.classes_)

X = df[FEATURES]
y = df["TargetEncoded"]


# =========================================================
# TRAIN / TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)


# =========================================================
# DECISION TREE
# =========================================================

decision_tree = DecisionTreeClassifier(
    random_state=42,
    max_depth=5
)

decision_tree.fit(X_train, y_train)

dt_prediction = decision_tree.predict(X_test)


# =========================================================
# RANDOM FOREST
# =========================================================

random_forest = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

random_forest.fit(X_train, y_train)

rf_prediction = random_forest.predict(X_test)


# =========================================================
# MODEL EVALUATION
# =========================================================

def calculate_metrics(actual, predicted):
    return {
        "accuracy": accuracy_score(actual, predicted),
        "precision": precision_score(
            actual,
            predicted,
            average="weighted",
            zero_division=0
        ),
        "recall": recall_score(
            actual,
            predicted,
            average="weighted",
            zero_division=0
        ),
        "f1": f1_score(
            actual,
            predicted,
            average="weighted",
            zero_division=0
        )
    }


dt_metrics = calculate_metrics(y_test, dt_prediction)
rf_metrics = calculate_metrics(y_test, rf_prediction)

print("\n================================")
print("MODEL PERFORMANCE")
print("================================")

print("\nDecision Tree")
print("Accuracy :", round(dt_metrics["accuracy"] * 100, 2), "%")
print("Precision:", round(dt_metrics["precision"] * 100, 2), "%")
print("Recall   :", round(dt_metrics["recall"] * 100, 2), "%")
print("F1 Score :", round(dt_metrics["f1"] * 100, 2), "%")

print("\nRandom Forest")
print("Accuracy :", round(rf_metrics["accuracy"] * 100, 2), "%")
print("Precision:", round(rf_metrics["precision"] * 100, 2), "%")
print("Recall   :", round(rf_metrics["recall"] * 100, 2), "%")
print("F1 Score :", round(rf_metrics["f1"] * 100, 2), "%")


# =========================================================
# SELECT MODEL
# =========================================================

if rf_metrics["f1"] >= dt_metrics["f1"]:
    model = random_forest
    selected_model = "Random Forest"
    selected_metrics = rf_metrics
else:
    model = decision_tree
    selected_model = "Decision Tree"
    selected_metrics = dt_metrics

print("\nSelected Model:", selected_model)


# =========================================================
# FIND POSITIVE CLASS
# =========================================================

# Try to identify "Placed"
placed_class = None

for i, class_name in enumerate(label_encoder.classes_):
    if str(class_name).lower() in [
        "placed",
        "yes",
        "1",
        "true"
    ]:
        placed_class = i
        break

# If "Placed" isn't found, use the last class
if placed_class is None:
    placed_class = len(label_encoder.classes_) - 1


# =========================================================
# DATABASE
# =========================================================

def create_database():

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT,
            cgpa REAL,
            aptitude REAL,
            technical REAL,
            communication REAL,
            internships INTEGER,
            certifications INTEGER,
            projects INTEGER,
            prediction TEXT,
            probability REAL,
            model TEXT,
            created_at TEXT
        )
    """)

    connection.commit()
    connection.close()


create_database()


# =========================================================
# HTML TEMPLATE
# =========================================================

HTML = """
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Student Placement Prediction System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>

        body {
            background: #f4f7fb;
        }

        .navbar {
            background: #172554;
        }

        .hero {
            background: linear-gradient(
                135deg,
                #1e3a8a,
                #2563eb
            );

            color: white;
            padding: 45px 20px;
            border-radius: 0 0 25px 25px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .result-card {
            border-left: 6px solid #16a34a;
        }

        .metric {
            font-size: 28px;
            font-weight: bold;
            color: #2563eb;
        }

    </style>

</head>

<body>

<nav class="navbar navbar-dark">

    <div class="container">

        <a class="navbar-brand fw-bold">
            Student Placement Prediction
        </a>

        <a href="/dashboard"
           class="btn btn-light">
            Dashboard
        </a>

    </div>

</nav>


<section class="hero text-center">

    <h1>AI-Based Student Placement Prediction</h1>

    <p class="lead">
        Predict student placement using machine learning
    </p>

</section>


<div class="container my-5">

    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="card p-4">

                <h3 class="mb-4">
                    Student Information
                </h3>

                <form method="POST"
                      action="/predict">

                    <div class="mb-3">

                        <label class="form-label">
                            Student Name
                        </label>

                        <input type="text"
                               name="student_name"
                               class="form-control"
                               required>

                    </div>


                    <div class="row">

                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                CGPA
                            </label>

                            <input type="number"
                                   name="cgpa"
                                   class="form-control"
                                   min="0"
                                   max="10"
                                   step="0.01"
                                   required>

                        </div>


                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Aptitude Score
                            </label>

                            <input type="number"
                                   name="aptitude"
                                   class="form-control"
                                   min="0"
                                   max="100"
                                   required>

                        </div>


                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Technical Skills
                            </label>

                            <input type="number"
                                   name="technical"
                                   class="form-control"
                                   min="0"
                                   max="100"
                                   required>

                        </div>


                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Communication Skills
                            </label>

                            <input type="number"
                                   name="communication"
                                   class="form-control"
                                   min="0"
                                   max="100"
                                   required>

                        </div>


                        <div class="col-md-4 mb-3">

                            <label class="form-label">
                                Internships
                            </label>

                            <input type="number"
                                   name="internships"
                                   class="form-control"
                                   min="0"
                                   required>

                        </div>


                        <div class="col-md-4 mb-3">

                            <label class="form-label">
                                Certifications
                            </label>

                            <input type="number"
                                   name="certifications"
                                   class="form-control"
                                   min="0"
                                   required>

                        </div>


                        <div class="col-md-4 mb-3">

                            <label class="form-label">
                                Projects
                            </label>

                            <input type="number"
                                   name="projects"
                                   class="form-control"
                                   min="0"
                                   required>

                        </div>

                    </div>


                    <button type="submit"
                            class="btn btn-primary btn-lg w-100">

                        Predict Placement

                    </button>

                </form>

            </div>


            {% if result %}

            <div class="card result-card mt-4 p-4 text-center">

                <h3>
                    Prediction Result
                </h3>

                <h2 class="
                    {% if 'Likely' in result %}
                        text-success
                    {% else %}
                        text-danger
                    {% endif %}
                ">

                    {{ result }}

                </h2>

                <h4>
                    Placement Probability:
                    {{ probability }}%
                </h4>

                <p class="text-muted">
                    Model used: {{ model_name }}
                </p>

            </div>

            {% endif %}

        </div>

    </div>

</div>

</body>
</html>
"""


# =========================================================
# HOME PAGE
# =========================================================

@app.route("/")
def home():

    return render_template_string(
        HTML,
        result=None
    )


# =========================================================
# PREDICTION
# =========================================================

@app.route("/predict", methods=["POST"])
def predict():

    student_name = request.form["student_name"]

    cgpa = float(request.form["cgpa"])
    aptitude = float(request.form["aptitude"])
    technical = float(request.form["technical"])
    communication = float(request.form["communication"])
    internships = int(request.form["internships"])
    certifications = int(request.form["certifications"])
    projects = int(request.form["projects"])

    input_data = pd.DataFrame([[
        cgpa,
        aptitude,
        technical,
        communication,
        internships,
        certifications,
        projects
    ]], columns=FEATURES)

    prediction_number = model.predict(input_data)[0]

    probabilities = model.predict_proba(input_data)[0]

    placement_probability = probabilities[placed_class] * 100

    if prediction_number == placed_class:

        result = "Likely to be Placed"

    else:

        result = "Unlikely to be Placed"


    # Save prediction
    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO predictions
        (
            student_name,
            cgpa,
            aptitude,
            technical,
            communication,
            internships,
            certifications,
            projects,
            prediction,
            probability,
            model,
            created_at
        )

        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        student_name,
        cgpa,
        aptitude,
        technical,
        communication,
        internships,
        certifications,
        projects,
        result,
        round(placement_probability, 2),
        selected_model,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))

    connection.commit()
    connection.close()


    return render_template_string(
        HTML,
        result=result,
        probability=round(placement_probability, 2),
        model_name=selected_model
    )


# =========================================================
# REST API
# =========================================================

@app.route("/api/predict", methods=["POST"])
def api_predict():

    data = request.get_json()

    input_data = pd.DataFrame([[
        float(data["cgpa"]),
        float(data["aptitude"]),
        float(data["technical"]),
        float(data["communication"]),
        int(data["internships"]),
        int(data["certifications"]),
        int(data["projects"])
    ]], columns=FEATURES)

    prediction_number = model.predict(input_data)[0]

    probabilities = model.predict_proba(input_data)[0]

    placement_probability = probabilities[placed_class] * 100

    if prediction_number == placed_class:
        result = "Likely to be Placed"
    else:
        result = "Unlikely to be Placed"

    return jsonify({
        "prediction": result,
        "probability": round(placement_probability, 2),
        "model": selected_model
    })


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute(
        "SELECT COUNT(*) FROM predictions"
    )

    total = cursor.fetchone()[0]


    cursor.execute(
        "SELECT COUNT(*) FROM predictions "
        "WHERE prediction='Likely to be Placed'"
    )

    placed = cursor.fetchone()[0]


    cursor.execute(
        "SELECT COUNT(*) FROM predictions "
        "WHERE prediction='Unlikely to be Placed'"
    )

    not_placed = cursor.fetchone()[0]


    if total > 0:
        placement_rate = round(
            (placed / total) * 100,
            2
        )
    else:
        placement_rate = 0


    cursor.execute("""
        SELECT
            student_name,
            cgpa,
            prediction,
            probability,
            model,
            created_at
        FROM predictions
        ORDER BY id DESC
    """)

    records = cursor.fetchall()

    connection.close()


    dashboard_html = """

    <!DOCTYPE html>

    <html>

    <head>

        <title>Placement Dashboard</title>

        <link href=
        "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    </head>


    <body class="bg-light">

    <div class="container py-5">

        <div class="d-flex justify-content-between mb-4">

            <h1>
                Placement Analytics Dashboard
            </h1>

            <a href="/"
               class="btn btn-primary">
                Prediction Form
            </a>

        </div>


        <div class="row g-4 mb-5">

            <div class="col-md-3">

                <div class="card p-4 text-center">

                    <h5>Total Predictions</h5>

                    <h2>
                        {{ total }}
                    </h2>

                </div>

            </div>


            <div class="col-md-3">

                <div class="card p-4 text-center">

                    <h5>Likely Placed</h5>

                    <h2 class="text-success">
                        {{ placed }}
                    </h2>

                </div>

            </div>


            <div class="col-md-3">

                <div class="card p-4 text-center">

                    <h5>Unlikely Placed</h5>

                    <h2 class="text-danger">
                        {{ not_placed }}
                    </h2>

                </div>

            </div>


            <div class="col-md-3">

                <div class="card p-4 text-center">

                    <h5>Placement Rate</h5>

                    <h2 class="text-primary">
                        {{ placement_rate }}%
                    </h2>

                </div>

            </div>

        </div>


        <div class="card p-4 mb-4">

            <h3>Model Performance</h3>

            <table class="table">

                <thead>

                    <tr>
                        <th>Model</th>
                        <th>Accuracy</th>
                        <th>Precision</th>
                        <th>Recall</th>
                        <th>F1 Score</th>
                    </tr>

                </thead>

                <tbody>

                    <tr>

                        <td>Decision Tree</td>

                        <td>
                            {{ dt_accuracy }}%
                        </td>

                        <td>
                            {{ dt_precision }}%
                        </td>

                        <td>
                            {{ dt_recall }}%
                        </td>

                        <td>
                            {{ dt_f1 }}%
                        </td>

                    </tr>


                    <tr>

                        <td>Random Forest</td>

                        <td>
                            {{ rf_accuracy }}%
                        </td>

                        <td>
                            {{ rf_precision }}%
                        </td>

                        <td>
                            {{ rf_recall }}%
                        </td>

                        <td>
                            {{ rf_f1 }}%
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>


        <div class="card p-4">

            <h3>Prediction History</h3>

            <div class="table-responsive">

            <table class="table table-striped">

                <thead>

                    <tr>

                        <th>Student</th>
                        <th>CGPA</th>
                        <th>Prediction</th>
                        <th>Probability</th>
                        <th>Model</th>
                        <th>Date</th>

                    </tr>

                </thead>

                <tbody>

                {% for r in records %}

                    <tr>

                        <td>{{ r[0] }}</td>

                        <td>{{ r[1] }}</td>

                        <td>{{ r[2] }}</td>

                        <td>{{ r[3] }}%</td>

                        <td>{{ r[4] }}</td>

                        <td>{{ r[5] }}</td>

                    </tr>

                {% endfor %}

                </tbody>

            </table>

            </div>

        </div>

    </div>

    </body>

    </html>

    """


    return render_template_string(
        dashboard_html,
        total=total,
        placed=placed,
        not_placed=not_placed,
        placement_rate=placement_rate,

        dt_accuracy=round(
            dt_metrics["accuracy"] * 100, 2
        ),

        dt_precision=round(
            dt_metrics["precision"] * 100, 2
        ),

        dt_recall=round(
            dt_metrics["recall"] * 100, 2
        ),

        dt_f1=round(
            dt_metrics["f1"] * 100, 2
        ),

        rf_accuracy=round(
            rf_metrics["accuracy"] * 100, 2
        ),

        rf_precision=round(
            rf_metrics["precision"] * 100, 2
        ),

        rf_recall=round(
            rf_metrics["recall"] * 100, 2
        ),

        rf_f1=round(
            rf_metrics["f1"] * 100, 2
        ),

        records=records
    )


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":

    print("\n========================================")
    print("STUDENT PLACEMENT PREDICTION SYSTEM")
    print("========================================")

    print("\nOpen your browser:")
    print("http://127.0.0.1:5000")

    print("\nDashboard:")
    print("http://127.0.0.1:5000/dashboard")

    app.run(
        debug=True
    )